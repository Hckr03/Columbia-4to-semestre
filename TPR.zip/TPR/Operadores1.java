public class Operadores1 {
	public static void main(String[] args){
		int i = 37;
		int j = 42;
		double x = 37.5;
		double y = 42.5;
        System.out.println(i);
        System.out.println(j);
		System.out.println(" i + j = "  + (i+j));
		System.out.println(" i - j = "  + (i-j));
		System.out.println(" i / j = "  + (i/j));
		System.out.println(" i % j = "  + (i%j));

        System.out.println(x);
        System.out.println(y);
        System.out.println(" x + y = " + (x+y));
		System.out.println(" x - y = " + (x-y));
		System.out.println(" x / y = " + (x/y));
		System.out.println(" x % y = " + (x%y));
    }
}
