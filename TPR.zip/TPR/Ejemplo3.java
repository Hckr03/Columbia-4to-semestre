public class Ejemplo3 {
    public static void main(String[] args){
        System.out.println("Hola");
        System.out.println("Que tal");

        System.out.print("Hola");
        System.out.print("Que tal");
    }
}