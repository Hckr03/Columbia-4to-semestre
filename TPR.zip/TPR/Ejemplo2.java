/**
 Comentario para la documentación
*/

/*
 Comentario
 de varias
 lineas
*/

// comentario de una sola linea

public class Ejemplo2 { //Definición de la clase

	public static void main(String[] args){ //método necesario para la ejecución
		//Declaración de variable
		String nombre; //String es el tipo de clase de dato y nombre es el nombre del atributo o variable
		//Asignación de variable
		nombre = "Gabriel";
		//Se puede declarar y asignar al mismo tiempo una variable
		String apellido = "Caballero";
		Integer cedula = 123456;

		System.out.println(nombre +" "+ apellido +" "+ cedula);
	}
}