public class Ejemplo4 {
    public static void main(String[] args) {
                //a
    int p, q;
    p = 10;
    q = 20;
    //b
    float x, y, z;
    x = 1.3f;
    y = 2.3f;
    z = 3.3f;
    //c
    char a, b, c;
    a = 'h';
    b = 'o';
    c = 'y';
    //d
    double raiz1, raiz2;
    raiz1 = 1.73;
    raiz2 = 3.14;
    //e
    long contador = 123456789;
    //f
    short indicador = 1;
    //g
    int indice = 1;
    //h
    double precio, precioFinal;
    precio = 2.900;
    precioFinal = 29.000;
    //I
    char car1, car2;
    car1 = 'V';
    car2 = 'T';
    //j
    byte bait = 0;
    //k
    boolean primero, ultimo;
    primero = true;
    ultimo = false;
    //l
    String nombre = "Gabriel Enrique Caballero Barrios"; 
    System.out.println("Aprendiendo a delcarar y asignar variables primitivas");
    }
}
    