package ManejoLista;

public class CI {
    private String nroCi, nomApellido, departamento, distrito;

    public CI(){}

    public String getNroCi() {
        return nroCi;
    }

    public void setNroCi(String nroCi) {
        this.nroCi = nroCi;
    }

    public String getNomApellido() {
        return nomApellido;
    }

    public void setNomApellido(String nomApellido) {
        this.nomApellido = nomApellido;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }
}
