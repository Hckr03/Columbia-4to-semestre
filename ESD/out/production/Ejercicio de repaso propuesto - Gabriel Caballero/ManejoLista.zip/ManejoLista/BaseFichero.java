package ManejoLista;

public interface BaseFichero {
    public boolean verificarFichero(String url);
    public boolean gestionarFichero(String url);
    public boolean cerrarFichero(String url);
}
