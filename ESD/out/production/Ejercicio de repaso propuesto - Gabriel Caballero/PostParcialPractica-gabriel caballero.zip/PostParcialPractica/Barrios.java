package PostParcialPractica;

public class Barrios extends Datos{

    public Barrios(){}

    public Barrios(Integer id, String descripcion){
        super(id, descripcion);
    }

}
