package Fichero;

public class Ruc {
    private String nroRuc;
    private String razonSocial;
    private String dv;
    private String rucAnterior;
    private String estado;

    public String getNroRuc() {
        return nroRuc;
    }

    public void setNroRuc(String nroRuc) {
        this.nroRuc = nroRuc;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getRucAnterior() {
        return rucAnterior;
    }

    public void setRucAnterior(String rucAnterior) {
        this.rucAnterior = rucAnterior;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
}
